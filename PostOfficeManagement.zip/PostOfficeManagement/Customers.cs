﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PostOfficeManagement
{
    public partial class Customers : Form
    {
        public Customers()
        {
            InitializeComponent();
            ShowCustomers();
            DateLbl.Text = DateTime.Today.Day + "-" + DateTime.Today.Month + "-" + DateTime.Today.Year;
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\OneDrive\Documents\PostOfficeDB.mdf;Integrated Security=True;Connect Timeout=30");
        private void ShowCustomers()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from CustomerTbl",con);
            SqlCommandBuilder Builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            custDGV.DataSource = ds.Tables[0];


            con.Close();
        }
        private void Customers_Load(object sender, EventArgs e)
        {

        }

        private void saveBtn_Click(object sender, EventArgs e)
        {
            if(custAddTb.Text == "" || custNameTb.Text == "" || custPhoneTb.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into CustomerTbl(CustName,CustDOB,CustPhone,CustAdd) values(@CN,@CD,@CP,@CA)",con);
                    cmd.Parameters.AddWithValue("@CN",custNameTb.Text);
                    cmd.Parameters.AddWithValue("@CD", custDOB.Value.Date);
                    cmd.Parameters.AddWithValue("@CP", custPhoneTb.Text);
                    cmd.Parameters.AddWithValue("@CA", custAddTb.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer Recorded Successfully!!!");
                    con.Close();
                    ShowCustomers();
                    Reset();
                }
                catch(Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void editBtn_Click(object sender, EventArgs e)
        {
            if (custAddTb.Text == "" || custNameTb.Text == "" || custPhoneTb.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("update CustomerTbl set CustName=@CN,CustDOB=@CD,CustPhone=@CP,CustAdd=@CA where CustNum=@CKey", con);
                    cmd.Parameters.AddWithValue("@CN", custNameTb.Text);
                    cmd.Parameters.AddWithValue("@CD", custDOB.Value.Date);
                    cmd.Parameters.AddWithValue("@CP", custPhoneTb.Text);
                    cmd.Parameters.AddWithValue("@CA", custAddTb.Text);
                    cmd.Parameters.AddWithValue("@CKey", Key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Updated Successfully!!!");
                    con.Close();
                    ShowCustomers();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
        int Key = 0;
        private void custDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            custNameTb.Text = custDGV.SelectedRows[0].Cells[1].Value.ToString();
            custDOB.Text = custDGV.SelectedRows[0].Cells[2].Value.ToString();
            custPhoneTb.Text = custDGV.SelectedRows[0].Cells[3].Value.ToString();
            custAddTb.Text = custDGV.SelectedRows[0].Cells[4].Value.ToString();
            if(custNameTb.Text == "")
            {
                Key = 0;
            }
            else
            {
                Key = Convert.ToInt32(custDGV.SelectedRows[0].Cells[0].Value.ToString());
            }
        }
        private void Reset()
        {
            custNameTb.Text = "";
            custPhoneTb.Text = "";
            custAddTb.Text = "";


        }
        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (Key == 0)
            {
                MessageBox.Show("Select Customer!!!");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("delete from CustomerTbl where CustNum=@CKey", con);
                    cmd.Parameters.AddWithValue("@CKey", Key);
                    
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer Deleted Successfully!!!");
                    con.Close();
                    ShowCustomers();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {
            MainMenu obj = new MainMenu();
            obj.Show();
            this.Hide();
        }

        private void custDOB_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
