﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PostOfficeManagement
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Login sc = new Login();
            sc.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            MoneyTrans sc = new MoneyTrans();
            sc.Show();
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Parcels sc = new Parcels();
            sc.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Customers sc = new Customers();
            sc.Show();
            this.Hide();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Delivery sc = new Delivery();
            sc.Show();
            this.Hide();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            MoneyTrans sc = new MoneyTrans();
            sc.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Parcels sc = new Parcels();
            sc.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Customers sc = new Customers();
            sc.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Delivery sc = new Delivery();
            sc.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Login sc = new Login();
            sc.Show();
            this.Hide();
        }
    }
}
