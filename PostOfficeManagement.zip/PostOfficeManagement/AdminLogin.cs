﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PostOfficeManagement
{
    public partial class AdminLogin : Form
    {
        public AdminLogin()
        {
            InitializeComponent();
        }

        private void ANameTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            if(PasswordTb.Text == "")
            {
                MessageBox.Show("Enter the Admin Password!!!");
            }
            else if(PasswordTb.Text == "pass")
            {
                Agents obj = new Agents();
                obj.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Wrong Password!!!");
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Login sc = new Login();
            sc.Show();
            this.Hide();
        }

        private void AdminLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
