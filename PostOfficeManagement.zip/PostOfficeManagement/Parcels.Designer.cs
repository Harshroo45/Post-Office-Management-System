﻿namespace PostOfficeManagement
{
    partial class Parcels
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Parcels));
            this.panel1 = new System.Windows.Forms.Panel();
            this.DateLbl = new System.Windows.Forms.Label();
            this.AgentLbl = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.ParcelDGV = new System.Windows.Forms.DataGridView();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label7 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.SendIDCb = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.PDate = new System.Windows.Forms.DateTimePicker();
            this.PSourceCb = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.RecNameTb = new System.Windows.Forms.TextBox();
            this.SNameTb = new System.Windows.Forms.TextBox();
            this.RecPhoneTb = new System.Windows.Forms.TextBox();
            this.PSAddressTb = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.DeleteBtn = new System.Windows.Forms.Button();
            this.EditBtn = new System.Windows.Forms.Button();
            this.SaveBtn = new System.Windows.Forms.Button();
            this.PacWTb = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.PacSTb = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.PacTypeCB = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.StatusCb = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.SPhoneTb = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ParcelDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.DateLbl);
            this.panel1.Controls.Add(this.AgentLbl);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1301, 114);
            this.panel1.TabIndex = 13;
            // 
            // DateLbl
            // 
            this.DateLbl.AutoSize = true;
            this.DateLbl.BackColor = System.Drawing.Color.Transparent;
            this.DateLbl.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.DateLbl.ForeColor = System.Drawing.Color.White;
            this.DateLbl.Location = new System.Drawing.Point(149, 68);
            this.DateLbl.Name = "DateLbl";
            this.DateLbl.Size = new System.Drawing.Size(67, 32);
            this.DateLbl.TabIndex = 25;
            this.DateLbl.Text = "Date";
            // 
            // AgentLbl
            // 
            this.AgentLbl.AutoSize = true;
            this.AgentLbl.BackColor = System.Drawing.Color.Transparent;
            this.AgentLbl.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.AgentLbl.ForeColor = System.Drawing.Color.White;
            this.AgentLbl.Location = new System.Drawing.Point(989, 68);
            this.AgentLbl.Name = "AgentLbl";
            this.AgentLbl.Size = new System.Drawing.Size(147, 32);
            this.AgentLbl.TabIndex = 24;
            this.AgentLbl.Text = "Agent Name";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(12, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(115, 88);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1239, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 42);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Copperplate Gothic Light", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(338, 34);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(597, 46);
            this.label6.TabIndex = 2;
            this.label6.Text = "Post office Management";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.ParcelDGV);
            this.panel2.Controls.Add(this.dataGridView1);
            this.panel2.Location = new System.Drawing.Point(12, 173);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(997, 406);
            this.panel2.TabIndex = 14;
            // 
            // ParcelDGV
            // 
            this.ParcelDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ParcelDGV.Location = new System.Drawing.Point(12, 12);
            this.ParcelDGV.Name = "ParcelDGV";
            this.ParcelDGV.RowHeadersWidth = 51;
            this.ParcelDGV.RowTemplate.Height = 29;
            this.ParcelDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ParcelDGV.Size = new System.Drawing.Size(973, 382);
            this.ParcelDGV.TabIndex = 3;
            this.ParcelDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ParcelDGV_CellContentClick);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.DarkSlateGray;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.Size = new System.Drawing.Size(991, 400);
            this.dataGridView1.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.ForeColor = System.Drawing.Color.DarkCyan;
            this.label7.Location = new System.Drawing.Point(479, 129);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(226, 34);
            this.label7.TabIndex = 19;
            this.label7.Text = "Manage Parcel";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.SendIDCb);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.PDate);
            this.panel3.Controls.Add(this.PSourceCb);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.RecNameTb);
            this.panel3.Controls.Add(this.SNameTb);
            this.panel3.Controls.Add(this.RecPhoneTb);
            this.panel3.Controls.Add(this.PSAddressTb);
            this.panel3.Location = new System.Drawing.Point(12, 596);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(997, 213);
            this.panel3.TabIndex = 15;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // SendIDCb
            // 
            this.SendIDCb.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SendIDCb.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SendIDCb.FormattingEnabled = true;
            this.SendIDCb.Location = new System.Drawing.Point(28, 61);
            this.SendIDCb.Name = "SendIDCb";
            this.SendIDCb.Size = new System.Drawing.Size(218, 34);
            this.SendIDCb.TabIndex = 1;
            this.SendIDCb.SelectionChangeCommitted += new System.EventHandler(this.SendIDCb_SelectionChangeCommitted);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(276, 31);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 27);
            this.label5.TabIndex = 4;
            this.label5.Text = "Source";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(28, 125);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(147, 27);
            this.label4.TabIndex = 2;
            this.label4.Text = "Parcel Date";
            // 
            // PDate
            // 
            this.PDate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PDate.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.PDate.Location = new System.Drawing.Point(28, 159);
            this.PDate.Name = "PDate";
            this.PDate.Size = new System.Drawing.Size(218, 34);
            this.PDate.TabIndex = 4;
            // 
            // PSourceCb
            // 
            this.PSourceCb.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PSourceCb.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PSourceCb.FormattingEnabled = true;
            this.PSourceCb.Items.AddRange(new object[] {
            "MUMBAI",
            "PUNE",
            "DELHI",
            "KOLKATTA",
            "HYDRABAD",
            "CHENNAI",
            "GUJARAT",
            "LACKNOW",
            "PANJAB",
            "RAJASTAN",
            "BENGLORE"});
            this.PSourceCb.Location = new System.Drawing.Point(276, 61);
            this.PSourceCb.Name = "PSourceCb";
            this.PSourceCb.Size = new System.Drawing.Size(216, 34);
            this.PSourceCb.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(756, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 27);
            this.label2.TabIndex = 1;
            this.label2.Text = "Address";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(276, 128);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(166, 27);
            this.label8.TabIndex = 1;
            this.label8.Text = "Sender Name";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(513, 26);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(190, 27);
            this.label9.TabIndex = 1;
            this.label9.Text = "Receiver Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(513, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(192, 27);
            this.label3.TabIndex = 1;
            this.label3.Text = "Receiver Phone";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(28, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 27);
            this.label1.TabIndex = 1;
            this.label1.Text = "Sender ID";
            // 
            // RecNameTb
            // 
            this.RecNameTb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RecNameTb.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RecNameTb.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.RecNameTb.Location = new System.Drawing.Point(513, 60);
            this.RecNameTb.Name = "RecNameTb";
            this.RecNameTb.Size = new System.Drawing.Size(216, 34);
            this.RecNameTb.TabIndex = 3;
            this.RecNameTb.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // SNameTb
            // 
            this.SNameTb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SNameTb.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SNameTb.Enabled = false;
            this.SNameTb.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SNameTb.Location = new System.Drawing.Point(276, 162);
            this.SNameTb.Name = "SNameTb";
            this.SNameTb.Size = new System.Drawing.Size(216, 34);
            this.SNameTb.TabIndex = 5;
            // 
            // RecPhoneTb
            // 
            this.RecPhoneTb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RecPhoneTb.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RecPhoneTb.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.RecPhoneTb.Location = new System.Drawing.Point(513, 162);
            this.RecPhoneTb.Name = "RecPhoneTb";
            this.RecPhoneTb.Size = new System.Drawing.Size(216, 34);
            this.RecPhoneTb.TabIndex = 6;
            // 
            // PSAddressTb
            // 
            this.PSAddressTb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PSAddressTb.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PSAddressTb.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PSAddressTb.Location = new System.Drawing.Point(756, 61);
            this.PSAddressTb.Multiline = true;
            this.PSAddressTb.Name = "PSAddressTb";
            this.PSAddressTb.Size = new System.Drawing.Size(219, 128);
            this.PSAddressTb.TabIndex = 7;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Controls.Add(this.DeleteBtn);
            this.panel5.Controls.Add(this.EditBtn);
            this.panel5.Controls.Add(this.SaveBtn);
            this.panel5.Location = new System.Drawing.Point(1026, 596);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(263, 213);
            this.panel5.TabIndex = 18;
            // 
            // DeleteBtn
            // 
            this.DeleteBtn.BackColor = System.Drawing.Color.LightCoral;
            this.DeleteBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DeleteBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.DeleteBtn.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.DeleteBtn.ForeColor = System.Drawing.Color.White;
            this.DeleteBtn.Location = new System.Drawing.Point(31, 148);
            this.DeleteBtn.Name = "DeleteBtn";
            this.DeleteBtn.Size = new System.Drawing.Size(209, 44);
            this.DeleteBtn.TabIndex = 15;
            this.DeleteBtn.Text = "Delete";
            this.DeleteBtn.UseVisualStyleBackColor = false;
            // 
            // EditBtn
            // 
            this.EditBtn.BackColor = System.Drawing.Color.Teal;
            this.EditBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.EditBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.EditBtn.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.EditBtn.ForeColor = System.Drawing.Color.White;
            this.EditBtn.Location = new System.Drawing.Point(31, 78);
            this.EditBtn.Name = "EditBtn";
            this.EditBtn.Size = new System.Drawing.Size(209, 44);
            this.EditBtn.TabIndex = 14;
            this.EditBtn.Text = "Edit";
            this.EditBtn.UseVisualStyleBackColor = false;
            this.EditBtn.Click += new System.EventHandler(this.EditBtn_Click);
            // 
            // SaveBtn
            // 
            this.SaveBtn.BackColor = System.Drawing.Color.SeaGreen;
            this.SaveBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SaveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.SaveBtn.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SaveBtn.ForeColor = System.Drawing.Color.White;
            this.SaveBtn.Location = new System.Drawing.Point(31, 14);
            this.SaveBtn.Name = "SaveBtn";
            this.SaveBtn.Size = new System.Drawing.Size(209, 44);
            this.SaveBtn.TabIndex = 13;
            this.SaveBtn.Text = "Save";
            this.SaveBtn.UseVisualStyleBackColor = false;
            this.SaveBtn.Click += new System.EventHandler(this.SaveBtn_Click);
            // 
            // PacWTb
            // 
            this.PacWTb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PacWTb.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PacWTb.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PacWTb.Location = new System.Drawing.Point(1026, 244);
            this.PacWTb.Name = "PacWTb";
            this.PacWTb.Size = new System.Drawing.Size(216, 34);
            this.PacWTb.TabIndex = 9;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(1026, 210);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(246, 27);
            this.label11.TabIndex = 21;
            this.label11.Text = "Package Weight(kg)";
            // 
            // PacSTb
            // 
            this.PacSTb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PacSTb.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PacSTb.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PacSTb.Location = new System.Drawing.Point(1026, 327);
            this.PacSTb.Name = "PacSTb";
            this.PacSTb.Size = new System.Drawing.Size(216, 34);
            this.PacSTb.TabIndex = 10;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(1026, 293);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(253, 27);
            this.label12.TabIndex = 21;
            this.label12.Text = "Package Size(inches)";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(1026, 382);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(67, 27);
            this.label13.TabIndex = 6;
            this.label13.Text = "Type";
            // 
            // PacTypeCB
            // 
            this.PacTypeCB.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PacTypeCB.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PacTypeCB.FormattingEnabled = true;
            this.PacTypeCB.Items.AddRange(new object[] {
            "ORDINARY",
            "DOCUMENT"});
            this.PacTypeCB.Location = new System.Drawing.Point(1026, 412);
            this.PacTypeCB.Name = "PacTypeCB";
            this.PacTypeCB.Size = new System.Drawing.Size(196, 34);
            this.PacTypeCB.TabIndex = 11;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label14.Location = new System.Drawing.Point(1026, 458);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(78, 27);
            this.label14.TabIndex = 23;
            this.label14.Text = "Status";
            // 
            // StatusCb
            // 
            this.StatusCb.Cursor = System.Windows.Forms.Cursors.Hand;
            this.StatusCb.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.StatusCb.FormattingEnabled = true;
            this.StatusCb.Items.AddRange(new object[] {
            "PENDING",
            "DELIVERED",
            "ON THE WAY"});
            this.StatusCb.Location = new System.Drawing.Point(1026, 489);
            this.StatusCb.Name = "StatusCb";
            this.StatusCb.Size = new System.Drawing.Size(196, 34);
            this.StatusCb.TabIndex = 12;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(1026, 144);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(168, 27);
            this.label10.TabIndex = 25;
            this.label10.Text = "Sender Phone";
            // 
            // SPhoneTb
            // 
            this.SPhoneTb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SPhoneTb.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SPhoneTb.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SPhoneTb.Location = new System.Drawing.Point(1026, 178);
            this.SPhoneTb.Name = "SPhoneTb";
            this.SPhoneTb.Size = new System.Drawing.Size(216, 34);
            this.SPhoneTb.TabIndex = 8;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 16.2F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point);
            this.label15.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label15.Location = new System.Drawing.Point(1111, 545);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(83, 34);
            this.label15.TabIndex = 38;
            this.label15.Text = "Back";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // Parcels
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1301, 819);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.SPhoneTb);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.StatusCb);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.PacTypeCB);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.PacSTb);
            this.Controls.Add(this.PacWTb);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Parcels";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Parcels";
            this.Load += new System.EventHandler(this.Parcels_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ParcelDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Panel panel1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private Label label6;
        private Panel panel2;
        private DataGridView dataGridView1;
        private Label label7;
        private Panel panel3;
        private Label label4;
        private DateTimePicker PDate;
        private Label label2;
        private Label label3;
        private Label label1;
        private TextBox RecPhoneTb;
        private TextBox PSAddressTb;
        private Panel panel5;
        private Button DeleteBtn;
        private Button EditBtn;
        private Button SaveBtn;
        private Label label5;
        private ComboBox PSourceCb;
        private Label label8;
        private Label label9;
        private TextBox RecNameTb;
        private TextBox SNameTb;
        private Label AgentLbl;
        private TextBox PacWTb;
        private Label label11;
        private TextBox PacSTb;
        private Label label12;
        private Label label13;
        private ComboBox PacTypeCB;
        private Label label14;
        private ComboBox StatusCb;
        private DataGridView ParcelDGV;
        private ComboBox SendIDCb;
        private Label label10;
        private TextBox SPhoneTb;
        private Label label15;
        private Label DateLbl;
    }
}