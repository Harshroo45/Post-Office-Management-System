using System.Data.SqlClient;
using System.Data;

namespace PostOfficeManagement
{
    public partial class Agents : Form
    {
        public Agents()
        {
            InitializeComponent();
            ShowAgents();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\OneDrive\Documents\PostOfficeDB.mdf;Integrated Security=True;Connect Timeout=30");
        private void ShowAgents()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from AgentTbl", con);
            SqlCommandBuilder Builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            AgentDGV.DataSource = ds.Tables[0];


            con.Close();
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Agents_Load(object sender, EventArgs e)
        {

        }
        private void Reset()
        {
            ANameTb.Text = "";
            APhoneTb.Text = "";
            AddressTb.Text = "";
            APasswordTb.Text = "";
        }
        private void SaveBtn_Click(object sender, EventArgs e)
        {
            if (AddressTb.Text == "" || ANameTb.Text == "" || APasswordTb.Text == "" || APhoneTb.Text == "" || AgentCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into AgentTbl(AgName,AgDOb,AgAdd,AgPhone,AgGen,AgPass) values(@AN,@AD,@AA,@AP,@AG,@APa)", con);
                    cmd.Parameters.AddWithValue("@AN", ANameTb.Text);
                    cmd.Parameters.AddWithValue("@AD", ADOB.Value.Date);
                    cmd.Parameters.AddWithValue("@AA", AddressTb.Text);
                    cmd.Parameters.AddWithValue("@AP", APhoneTb.Text);
                    cmd.Parameters.AddWithValue("@AG", AgentCb.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@APa", APasswordTb.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Agent Recorded Successfully!!!");
                    con.Close();
                    ShowAgents();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void EditBtn_Click(object sender, EventArgs e)
        {
            if (AddressTb.Text == "" || ANameTb.Text == "" || APasswordTb.Text == "" || APhoneTb.Text == "" || AgentCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("update AgentTbl set AgName=@AN,AgDOB=@AD,AgAdd=@AA,AgPhone=@AP,AgGen=@AG,AgPass=@APa where AgNum=@AKey", con);
                    cmd.Parameters.AddWithValue("@AN", ANameTb.Text);
                    cmd.Parameters.AddWithValue("@AD", ADOB.Value.Date);
                    cmd.Parameters.AddWithValue("@AA", AddressTb.Text);
                    cmd.Parameters.AddWithValue("@AP", APhoneTb.Text);
                    cmd.Parameters.AddWithValue("@AG", AgentCb.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@APa", APasswordTb.Text);
                    cmd.Parameters.AddWithValue("@AKey", Key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Agent Recorded Successfully!!!");
                    con.Close();
                    ShowAgents();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
        int Key = 0;
        private void AgentDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ANameTb.Text = AgentDGV.SelectedRows[0].Cells[1].Value.ToString();
            ADOB.Value = Convert.ToDateTime(AgentDGV.SelectedRows[0].Cells[2].Value.ToString());
            AddressTb.Text = AgentDGV.SelectedRows[0].Cells[3].Value.ToString();
            APhoneTb.Text = AgentDGV.SelectedRows[0].Cells[4].Value.ToString();
            AgentCb.SelectedItem = AgentDGV.SelectedRows[0].Cells[5].Value.ToString();
            APasswordTb.Text = AgentDGV.SelectedRows[0].Cells[6].Value.ToString();
            if (ANameTb.Text == "")
            {
                Key = 0;
            }
            else
            {
                Key = Convert.ToInt32(AgentDGV.SelectedRows[0].Cells[0].Value.ToString());
            }
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            if (Key == 0)
            {
                MessageBox.Show("Select Agent!!!");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("delete from AgentTbl where AgNum=@AKey", con);
                    cmd.Parameters.AddWithValue("@AKey", Key);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Agent Deleted Successfully!!!");
                    con.Close();
                    ShowAgents();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {
            Login sc = new Login();
            sc.Show();
            this.Hide();
        }

        private void ANameTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void ADOB_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}