﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PostOfficeManagement
{
    public partial class Delivery : Form
    {
        public Delivery()
        {
            InitializeComponent();
            ShowDelivery();
            GetAgentId();
            GetParcel();
            DateLbl.Text = DateTime.Today.Day + "-" + DateTime.Today.Month + "-" + DateTime.Today.Year;

        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\OneDrive\Documents\PostOfficeDB.mdf;Integrated Security=True;Connect Timeout=30");
        private void ShowDelivery()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from DeliveryTbl", con);
            SqlCommandBuilder Builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            DeliveryDGV.DataSource = ds.Tables[0];


            con.Close();
        }
        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
        private void GetAgentName()
        {
            con.Open();
            string query = "select * from AgentTbl where AgNum=" + AgNumCb.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(query, con);
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                AgNameTb.Text = dr["AgName"].ToString();
            }
            con.Close();
        }
        private void GetAgentId()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from AgentTbl", con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("AgNum", typeof(int));
            dt.Load(rdr);
            AgNumCb.ValueMember = "AgNum";
            AgNumCb.DataSource = dt;
            con.Close();
        }
        private void GetParcel()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from ParcelTbl", con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("PNum", typeof(int));
            dt.Load(rdr);
            ParNumCb.ValueMember = "PNum";
            ParNumCb.DataSource = dt;
            con.Close();
        }
        private void Reset()
        {
            FeesTb.Text = "";
            AgNameTb.Text = "";
            AgNumCb.SelectedIndex = -1;
            ParNumCb.SelectedIndex = -1;
        }
        private void SaveBtn_Click(object sender, EventArgs e)
        {
            if (ParNumCb.SelectedIndex == -1 || AgNameTb.Text == "" || FeesTb.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into DeliveryTbl(PrNum,DelDate,AgentNum,AgentName,DelFees) values(@PN,@DD,@ANum,@AName,@DelFees)", con);
                    cmd.Parameters.AddWithValue("@PN", ParNumCb.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@DD", DelDate.Value.Date);
                    cmd.Parameters.AddWithValue("@ANum", AgNumCb.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@AName", AgNameTb.Text);
                    cmd.Parameters.AddWithValue("@DelFees", FeesTb.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Packet Delivered Successfully!!!");
                    con.Close();
                    ShowDelivery();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void AgNumCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            GetAgentName();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            MainMenu obj = new MainMenu();
            obj.Show();
            this.Hide();
        }

        private void Delivery_Load(object sender, EventArgs e)
        {

        }
    }
}
